package com.example.lab2.entities

enum class BadgeType {
    SPEED,
    PRECISION,
    TEAM_WORK,
    STRATEGY,
    ENDURANCE
}