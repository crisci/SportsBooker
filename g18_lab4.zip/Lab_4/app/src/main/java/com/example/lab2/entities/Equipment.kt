package com.example.lab2.entities

data class Equipment(
    val name: String,
    val price: Double
)

